# Small_Lo's data v2 > 2026-01-25 10:04pm
https://universe.roboflow.com/ntubyolo/small_lo-s-data-v2

Provided by a Roboflow user
License: CC BY 4.0

