# Jie-Dataset

Due to GitHub file size limits, YOLO training datasets are not included in this repository.

Please download the dataset from:

- Google Drive:  https://drive.google.com/file/d/1UMV4ZZDEHHsH5BJG5xMZoYxTExlDbZJU/view?usp=sharing
- Or generate it using the provided scripts.